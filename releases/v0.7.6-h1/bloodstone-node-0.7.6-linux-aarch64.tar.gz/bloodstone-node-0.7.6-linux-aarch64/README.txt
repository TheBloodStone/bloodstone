Bloodstone Node v0.7.6
Linux ARM64 (aarch64) — Raspberry Pi 4/5 with 64-bit OS

Packaged 2026-07-20 18:56 UTC

Supported hardware:
  - Raspberry Pi 4 / Pi 5 running Raspberry Pi OS 64-bit (aarch64)
  - Other ARM64 SBCs (Ubuntu ARM64, Debian arm64)

Contents:
  bin/bloodstoned              — full node daemon (P2P + RPC)
  bin/bloodstone-cli           — command-line RPC client (if built)
  bloodstone.conf.example
  start-node.sh                — config + FULL chain bootstrap + start
  install-chain-bootstrap.sh   — shared bootstrap helper

Quick start on Raspberry Pi:
  tar -xzf bloodstone-node-0.7.6-linux-aarch64.tar.gz
  cd bloodstone-node-0.7.6-linux-aarch64
  ./start-node.sh
  # First run downloads full chain bootstrap (~7 MB tip snapshot), then starts bloodstoned
  ./bin/bloodstone-cli -conf=$HOME/.bloodstone/bloodstone.conf getblockchaininfo

Bootstrap (automatic on first start-node.sh):
  URL: https://bloodstonewallet.mytunnel.org/downloads/bloodstone-chain-bootstrap-latest.tar.gz
  Includes blocks/ + chainstate/ + block index (+ txindex when published)
  Skips slow IBD and known stuck heights (~10100–10103)

  BLOODSTONE_SKIP_BOOTSTRAP=1 ./start-node.sh     # full P2P IBD instead
  BLOODSTONE_FORCE_BOOTSTRAP=1 ./start-node.sh    # reinstall tip snapshot
  BLOODSTONE_DATADIR=/mnt/ssd/bloodstone ./start-node.sh

Tip: use an external USB SSD for datadir on Pi:
  echo 'datadir=/mnt/ssd/bloodstone' >> bloodstone.conf

Default ports: P2P 17333, RPC 18332
Genesis: df04225074039e630dad825b24818a695462bd19cd585131a0568f50e9bf71d0
Algorithms: neoscrypt, yespower, sha256d (all valid from block 1)
