#!/usr/bin/env bash
# Start Bloodstone full node on Raspberry Pi / Linux ARM64.
# Installs full chain bootstrap on first run (skips slow IBD / stuck heights).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export BLOODSTONE_DATADIR="${BLOODSTONE_DATADIR:-$HOME/.bloodstone}"
CONF_DIR="$BLOODSTONE_DATADIR"
CONF_FILE="$CONF_DIR/bloodstone.conf"
mkdir -p "$CONF_DIR"
if [[ ! -f "$CONF_FILE" ]]; then
  cp "$ROOT/bloodstone.conf.example" "$CONF_FILE"
  # Prefer random rpc password on fresh installs
  if grep -q 'CHANGE_ME\|rpcpassword=$' "$CONF_FILE" 2>/dev/null || ! grep -q '^rpcpassword=' "$CONF_FILE"; then
    if command -v openssl >/dev/null 2>&1; then
      pass="$(openssl rand -hex 16)"
      if grep -q '^rpcpassword=' "$CONF_FILE"; then
        sed -i "s|^rpcpassword=.*|rpcpassword=${pass}|" "$CONF_FILE"
      else
        echo "rpcpassword=${pass}" >> "$CONF_FILE"
      fi
    fi
  fi
  # Ensure seed peers (addnode only — never exclusive connect=)
  grep -q '^addnode=64.188.22.190:17333' "$CONF_FILE" || echo 'addnode=64.188.22.190:17333' >> "$CONF_FILE"
  grep -q '^addnode=192.119.82.145:17333' "$CONF_FILE" || echo 'addnode=192.119.82.145:17333' >> "$CONF_FILE"
  if grep -q '^connect=' "$CONF_FILE"; then
    grep -v '^connect=' "$CONF_FILE" > "${CONF_FILE}.tmp" && mv "${CONF_FILE}.tmp" "$CONF_FILE"
  fi
  echo "Created $CONF_FILE — edit rpcuser/rpcpassword before exposing RPC."
fi

# Full tip snapshot (blocks + chainstate + index [+ txindex when published])
if [[ -x "$ROOT/install-chain-bootstrap.sh" ]]; then
  # shellcheck source=/dev/null
  source "$ROOT/install-chain-bootstrap.sh"
  install_chain_bootstrap
elif [[ -f "$ROOT/install-chain-bootstrap.sh" ]]; then
  bash "$ROOT/install-chain-bootstrap.sh"
fi

exec "$ROOT/bin/bloodstoned" -conf="$CONF_FILE" -daemon "$@"
