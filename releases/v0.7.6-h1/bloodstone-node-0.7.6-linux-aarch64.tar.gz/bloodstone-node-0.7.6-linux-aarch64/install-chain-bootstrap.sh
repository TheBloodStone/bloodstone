#!/usr/bin/env bash
# Shared chain bootstrap for headless Bloodstone nodes (Pi ARM64, Linux x86_64).
# Sourced or exec'd from start-node.sh. Keeps wallets; only refreshes chain data.
#
# Env:
#   BLOODSTONE_DATADIR                 default ~/.bloodstone
#   BLOODSTONE_CHAIN_BOOTSTRAP_URL     snapshot URL
#   BLOODSTONE_SKIP_BOOTSTRAP=1        skip (full P2P IBD)
#   BLOODSTONE_FORCE_BOOTSTRAP=1       reinstall even if data exists
#   BLOODSTONE_MIN_BOOTSTRAP_HEIGHT    reinstall if marker below this (default 10200)
#   BLOODSTONE_PUBLIC_ROOT             default https://bloodstonewallet.mytunnel.org

set -euo pipefail

PUBLIC_ROOT="${BLOODSTONE_PUBLIC_ROOT:-https://bloodstonewallet.mytunnel.org}"
BOOTSTRAP_URL="${BLOODSTONE_CHAIN_BOOTSTRAP_URL:-${PUBLIC_ROOT}/downloads/bloodstone-chain-bootstrap-latest.tar.gz}"
BOOTSTRAP_SHA_URL="${BLOODSTONE_CHAIN_BOOTSTRAP_SHA_URL:-${BOOTSTRAP_URL}.sha256}"
SKIP_BOOTSTRAP="${BLOODSTONE_SKIP_BOOTSTRAP:-0}"
FORCE_BOOTSTRAP="${BLOODSTONE_FORCE_BOOTSTRAP:-0}"
MIN_BOOTSTRAP_HEIGHT="${BLOODSTONE_MIN_BOOTSTRAP_HEIGHT:-10200}"
DATADIR="${BLOODSTONE_DATADIR:-${HOME}/.bloodstone}"

log() { echo "[node-bootstrap] $*"; }

needs_bootstrap() {
  if [[ "$FORCE_BOOTSTRAP" == "1" ]]; then
    return 0
  fi
  if [[ ! -d "${DATADIR}/blocks" ]] || [[ ! -d "${DATADIR}/chainstate" ]]; then
    return 0
  fi
  if [[ -f "${DATADIR}/.bootstrap-height" ]]; then
    local h
    h="$(tr -cd '0-9' < "${DATADIR}/.bootstrap-height" || true)"
    if [[ -n "$h" && "$h" -lt "$MIN_BOOTSTRAP_HEIGHT" ]]; then
      log "Existing bootstrap height $h < $MIN_BOOTSTRAP_HEIGHT — reinstalling"
      return 0
    fi
  fi
  return 1
}

install_chain_bootstrap() {
  if [[ "$SKIP_BOOTSTRAP" == "1" ]]; then
    log "Skipping chain bootstrap (BLOODSTONE_SKIP_BOOTSTRAP=1)"
    return 0
  fi
  if ! needs_bootstrap; then
    log "Chain data present under $DATADIR — skip bootstrap (BLOODSTONE_FORCE_BOOTSTRAP=1 to reinstall)"
    return 0
  fi

  mkdir -p "$DATADIR"
  # Wipe chain only (never wallets).
  for name in blocks chainstate indexes mempool.dat fee_estimates.dat .lock bloodstoned.pid \
    .bootstrap-height .bootstrap-includes-index .bootstrap-includes-txindex .bootstrap-reindex; do
    rm -rf "${DATADIR:?}/${name}"
  done

  local tmp archive shafile
  tmp="$(mktemp -d)"
  archive="${tmp}/bootstrap.tar.gz"
  shafile="${tmp}/bootstrap.sha256"
  # shellcheck disable=SC2064
  trap "rm -rf '$tmp'" RETURN

  log "Downloading full chain bootstrap:"
  log "  $BOOTSTRAP_URL"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --retry 3 --retry-delay 2 -o "$archive" "$BOOTSTRAP_URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$archive" "$BOOTSTRAP_URL"
  else
    echo "curl or wget required for chain bootstrap" >&2
    exit 1
  fi
  local size
  size="$(wc -c < "$archive" | tr -d ' ')"
  log "Downloaded ${size} bytes"

  # Integrity: require published .sha256 unless emergency override
  local allow_unverified="${BLOODSTONE_BOOTSTRAP_ALLOW_UNVERIFIED:-0}"
  if command -v curl >/dev/null 2>&1 && curl -fsSL --retry 2 -o "$shafile" "$BOOTSTRAP_SHA_URL" 2>/dev/null; then
    local expected actual
    expected="$(awk '{print $1; exit}' "$shafile" | tr 'A-F' 'a-f' | tr -cd '0-9a-f')"
    actual="$(sha256sum "$archive" | awk '{print $1}')"
    if [[ -z "$expected" || ${#expected} -ne 64 ]]; then
      echo "Bootstrap checksum file invalid" >&2
      exit 1
    fi
    if [[ "$expected" != "$actual" ]]; then
      echo "Bootstrap SHA256 mismatch (expected $expected got $actual)" >&2
      exit 1
    fi
    log "SHA256 OK"
  else
    if [[ "$allow_unverified" == "1" ]]; then
      log "WARN: could not verify SHA256 — continuing (BLOODSTONE_BOOTSTRAP_ALLOW_UNVERIFIED=1)"
    else
      echo "Bootstrap checksum download failed — refusing extract. Set BLOODSTONE_BOOTSTRAP_ALLOW_UNVERIFIED=1 only in emergencies." >&2
      exit 1
    fi
  fi

  # Reject path traversal / absolute members (tar slip)
  local member unsafe=0
  while IFS= read -r member; do
    if [[ "$member" == /* ]] || [[ "$member" == ../* ]] || [[ "$member" == */../* ]] \
      || [[ "$member" == */.. ]] || [[ "$member" == .. ]]; then
      echo "Unsafe archive member: $member" >&2
      unsafe=1
      break
    fi
  done < <(tar -tzf "$archive" 2>/dev/null || true)
  if [[ "$unsafe" -ne 0 ]]; then
    exit 1
  fi

  log "Extracting into $DATADIR ..."
  tar -xzf "$archive" -C "$DATADIR"
  [[ -d "${DATADIR}/blocks" ]] || {
    echo "Bootstrap extract failed — blocks/ missing" >&2
    exit 1
  }
  [[ -d "${DATADIR}/chainstate" ]] || log "WARN: chainstate missing — first start may reindex"

  local height="?"
  if [[ -f "${DATADIR}/.bootstrap-height" ]]; then
    height="$(tr -cd '0-9' < "${DATADIR}/.bootstrap-height")"
  fi
  log "Full chain bootstrap installed (height marker: ${height})"
  if [[ -d "${DATADIR}/indexes/txindex" ]]; then
    log "txindex included (good for explorers / deposit lookups)"
  fi
}

# When executed directly (not only sourced):
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  install_chain_bootstrap
fi
