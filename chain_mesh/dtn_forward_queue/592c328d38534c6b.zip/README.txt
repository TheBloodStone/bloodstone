Bloodstone DTN sync bundle (Wave C)
Import: POST /api/convergence/dtn/import
Offline Pi nodes queue bundles via /api/convergence/dtn/forward/submit
Flush on brief uplink: POST /api/convergence/dtn/forward/flush
